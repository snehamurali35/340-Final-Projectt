package com.example.neurolog

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
