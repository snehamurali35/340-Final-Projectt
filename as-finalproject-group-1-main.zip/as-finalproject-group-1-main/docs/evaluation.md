# Instructions:

- You should evaluate the usability of your application, as well as its utility – how well it addresses the need you have designed for.
- You must SUS Test your app with at least 9 people.
- You may also use additional methods to evaluate your app, including interviews and surveys (but if you survey, we want to know how you constructed an appropriate sample).

For evaluation of our app, we used a google form with various questions about the functionality/usability of our app, and we sent it out to people that we know to get feedback. We were able to get feedback about our app in order to complete sus testing.

https://docs.google.com/forms/d/e/1FAIpQLSeHlW0j0N-2y1je18eH6gVu6WocW9N98k0ao7x7f-yS03DlyA/viewform?usp=header

We also asked for the same people to give us feedback on aspects of our app that required more input, such as whether the data persistance aspect worked, and if the internationalization covered the main parts of the app. This feedback helped us fix our calendar view, since users were previously not able to view a migraine log on the current date, and edit it. Also, it helped us realize that the internationalization did not cover the navigation bar, and parts of the calendar view;we fixed this as well.
